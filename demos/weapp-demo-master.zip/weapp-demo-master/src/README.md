# Source

## Auto convert

- js                =>  js
- xml               =>  wxml
- {css,less,scss}   =>  wxss
- json              =>  json
