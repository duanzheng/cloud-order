# wechat-weapp-demo
一个简单的微信小程序购物车DEMO

![](./demo1.png)
![](./demo2.png)

### 展示的数据为纯静态数据，只为熟悉组件和基本用法。

注：仅【堂食】这个类别下有demo数据

[微信小程序文档](https://mp.weixin.qq.com/debug/wxadoc/dev/index.html)

更多信息及开发工具下载：
[传送门](https://github.com/justjavac/awesome-wechat-weapp)
